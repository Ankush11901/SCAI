<?php
/**
 * SCAI Connector — Editor AJAX Handler.
 *
 * Handles saving the section-level editor form.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SCAI_Editor_Ajax {

	/**
	 * Register AJAX actions.
	 */
	public static function register() {
		add_action( 'wp_ajax_scai_save_editor', array( __CLASS__, 'save_editor' ) );
	}

	/**
	 * Save the editor form data.
	 */
	public static function save_editor() {
		check_ajax_referer( 'scai_save_editor', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied.' ), 403 );
		}

		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		if ( ! $post_id ) {
			wp_send_json_error( array( 'message' => 'Missing post ID.' ) );
		}

		$post = get_post( $post_id );
		if ( ! $post || strpos( $post->post_content, 'wp:scai/article' ) === false ) {
			wp_send_json_error( array( 'message' => 'Post not found or not an SCAI article.' ) );
		}

		// Parse the components from the form data.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- We sanitize each field individually below.
		$raw_components = isset( $_POST['components'] ) ? $_POST['components'] : array();

		if ( empty( $raw_components ) || ! is_array( $raw_components ) ) {
			wp_send_json_error( array( 'message' => 'No components to save.' ) );
		}

		// Sanitize each component.
		$components = array();
		foreach ( $raw_components as $index => $comp ) {
			$components[] = self::sanitize_component( $comp );
		}

		// Rebuild the HTML.
		$new_content = SCAI_Editor::rebuild_html( $post_id, $components );

		// Update the post.
		$result = wp_update_post( array(
			'ID'           => $post_id,
			'post_content' => $new_content,
		), true );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => 'Failed to save: ' . $result->get_error_message() ) );
		}

		// Also update the post title if the h1 changed.
		foreach ( $components as $comp ) {
			if ( $comp['type'] === 'scai-h1' && ! empty( $comp['title'] ) ) {
				wp_update_post( array(
					'ID'         => $post_id,
					'post_title' => sanitize_text_field( $comp['title'] ),
				) );
				break;
			}
		}

		wp_send_json_success( array( 'message' => 'Article saved successfully.' ) );
	}

	/**
	 * Sanitize a single component's data.
	 */
	private static function sanitize_component( $comp ) {
		$sanitized = array(
			'type'       => isset( $comp['type'] ) ? sanitize_key( $comp['type'] ) : '',
			'outer_html' => isset( $comp['outer_html'] ) ? $comp['outer_html'] : '',
		);

		$type = $sanitized['type'];

		switch ( $type ) {
			case 'scai-h1':
				$sanitized['title'] = isset( $comp['title'] ) ? sanitize_text_field( $comp['title'] ) : '';
				break;

			case 'scai-featured-image':
				$sanitized['src'] = isset( $comp['src'] ) ? esc_url_raw( $comp['src'] ) : '';
				$sanitized['alt'] = isset( $comp['alt'] ) ? sanitize_text_field( $comp['alt'] ) : '';
				$sanitized['caption'] = isset( $comp['caption'] ) ? sanitize_text_field( $comp['caption'] ) : '';
				break;

			case 'scai-overview':
				$sanitized['paragraphs'] = self::sanitize_paragraphs( isset( $comp['paragraphs'] ) ? $comp['paragraphs'] : array() );
				break;

			case 'scai-table-of-contents':
				$sanitized['auto'] = true;
				break;

			case 'scai-section':
				$sanitized['heading'] = isset( $comp['heading'] ) ? sanitize_text_field( $comp['heading'] ) : '';
				$sanitized['section_id'] = isset( $comp['section_id'] ) ? sanitize_key( $comp['section_id'] ) : '';
				$sanitized['image_src'] = isset( $comp['image_src'] ) ? esc_url_raw( $comp['image_src'] ) : '';
				$sanitized['image_alt'] = isset( $comp['image_alt'] ) ? sanitize_text_field( $comp['image_alt'] ) : '';
				$sanitized['image_caption'] = isset( $comp['image_caption'] ) ? sanitize_text_field( $comp['image_caption'] ) : '';
				$sanitized['paragraphs'] = self::sanitize_paragraphs( isset( $comp['paragraphs'] ) ? $comp['paragraphs'] : array() );
				break;

			case 'scai-faq-section':
				$sanitized['title'] = isset( $comp['title'] ) ? sanitize_text_field( $comp['title'] ) : '';
				$sanitized['items'] = array();
				if ( isset( $comp['items'] ) && is_array( $comp['items'] ) ) {
					foreach ( $comp['items'] as $item ) {
						if ( ! empty( $item['q'] ) || ! empty( $item['a'] ) ) {
							$sanitized['items'][] = array(
								'q' => sanitize_text_field( $item['q'] ),
								'a' => sanitize_textarea_field( $item['a'] ),
							);
						}
					}
				}
				break;

			case 'scai-product-card':
				$sanitized['name'] = isset( $comp['name'] ) ? sanitize_text_field( $comp['name'] ) : '';
				$sanitized['rating'] = isset( $comp['rating'] ) ? sanitize_text_field( $comp['rating'] ) : '';
				$sanitized['price'] = isset( $comp['price'] ) ? sanitize_text_field( $comp['price'] ) : '';
				$sanitized['description'] = isset( $comp['description'] ) ? sanitize_textarea_field( $comp['description'] ) : '';
				$sanitized['cta_text'] = isset( $comp['cta_text'] ) ? sanitize_text_field( $comp['cta_text'] ) : '';
				$sanitized['cta_url'] = isset( $comp['cta_url'] ) ? esc_url_raw( $comp['cta_url'] ) : '';
				$sanitized['image_src'] = isset( $comp['image_src'] ) ? esc_url_raw( $comp['image_src'] ) : '';
				$sanitized['badge'] = isset( $comp['badge'] ) ? sanitize_text_field( $comp['badge'] ) : '';
				break;

			case 'scai-service-info-box':
				$sanitized['header'] = isset( $comp['header'] ) ? sanitize_text_field( $comp['header'] ) : '';
				$sanitized['rows'] = array();
				if ( isset( $comp['rows'] ) && is_array( $comp['rows'] ) ) {
					foreach ( $comp['rows'] as $row ) {
						if ( ! empty( $row['label'] ) || ! empty( $row['value'] ) ) {
							$sanitized['rows'][] = array(
								'label' => sanitize_text_field( $row['label'] ),
								'value' => sanitize_text_field( $row['value'] ),
							);
						}
					}
				}
				break;

			case 'scai-why-local-section':
				$sanitized['title'] = isset( $comp['title'] ) ? sanitize_text_field( $comp['title'] ) : '';
				$sanitized['badge'] = isset( $comp['badge'] ) ? sanitize_text_field( $comp['badge'] ) : '';
				$sanitized['image_src'] = isset( $comp['image_src'] ) ? esc_url_raw( $comp['image_src'] ) : '';
				$sanitized['items'] = array();
				if ( isset( $comp['items'] ) && is_array( $comp['items'] ) ) {
					foreach ( $comp['items'] as $item ) {
						$text = sanitize_text_field( $item );
						if ( ! empty( $text ) ) {
							$sanitized['items'][] = $text;
						}
					}
				}
				break;

			case 'scai-closing':
				$sanitized['heading'] = isset( $comp['heading'] ) ? sanitize_text_field( $comp['heading'] ) : '';
				$sanitized['paragraphs'] = self::sanitize_paragraphs( isset( $comp['paragraphs'] ) ? $comp['paragraphs'] : array() );
				break;

			default:
				// Generic — allow HTML but run through wp_kses_post.
				$sanitized['html'] = isset( $comp['html'] ) ? wp_kses_post( $comp['html'] ) : '';
				break;
		}

		return $sanitized;
	}

	/**
	 * Sanitize an array of paragraphs.
	 */
	private static function sanitize_paragraphs( $paragraphs ) {
		if ( ! is_array( $paragraphs ) ) {
			return array();
		}
		$clean = array();
		foreach ( $paragraphs as $p ) {
			$text = sanitize_textarea_field( $p );
			if ( ! empty( trim( $text ) ) ) {
				$clean[] = $text;
			}
		}
		return $clean;
	}
}
