/**
 * SCAI Connector — Section-Level Article Editor JavaScript
 *
 * Handles: sidebar add-component, reorder, delete, repeater add/remove,
 * unsaved changes warning, AJAX save, image preview updates, sidebar toggle.
 *
 * Expects `scaiEditor` global from wp_localize_script:
 *   { ajaxUrl, nonce, postId }
 */

(function () {
  'use strict';

  var hasChanges = false;
  var cardsContainer = document.getElementById('scai-editor-cards');
  var form = document.getElementById('scai-editor-form');
  var saveBtn = document.getElementById('scai-save-editor');

  if (!form || !cardsContainer) return;

  /* ═══════════════════════════════════════════════════════════════
     UNSAVED CHANGES TRACKING
     ═══════════════════════════════════════════════════════════════ */

  function markDirty() {
    if (!hasChanges) {
      hasChanges = true;
      var bar = document.getElementById('scai-unsaved-bar');
      if (bar) bar.style.display = 'flex';
    }
  }

  function markClean() {
    hasChanges = false;
    var bar = document.getElementById('scai-unsaved-bar');
    if (bar) bar.style.display = 'none';
  }

  form.addEventListener('input', markDirty);

  window.addEventListener('beforeunload', function (e) {
    if (hasChanges) {
      e.preventDefault();
      e.returnValue = '';
    }
  });

  /* ═══════════════════════════════════════════════════════════════
     SIDEBAR TOGGLE
     ═══════════════════════════════════════════════════════════════ */

  var sidebar = document.getElementById('sce-sidebar');
  var sidebarToggle = document.getElementById('sce-sidebar-toggle');

  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener('click', function () {
      sidebar.classList.toggle('collapsed');
    });
  }

  /* ═══════════════════════════════════════════════════════════════
     SIDEBAR — ADD COMPONENT
     ═══════════════════════════════════════════════════════════════ */

  var componentTemplates = {
    'scai-section': function (idx) {
      return buildCard(idx, 'scai-section', 'Content Section', [
        hiddenField(idx, 'type', 'scai-section'),
        hiddenField(idx, 'outer_html', ''),
        textField(idx, '[heading]', 'Section Heading', ''),
        paragraphsRepeater(idx, [])
      ]);
    },
    'scai-faq-section': function (idx) {
      return buildCard(idx, 'scai-faq-section', 'FAQ', [
        hiddenField(idx, 'type', 'scai-faq-section'),
        hiddenField(idx, 'outer_html', ''),
        textField(idx, '[title]', 'FAQ Section Title', 'Frequently Asked Questions'),
        faqRepeater(idx, [])
      ]);
    },
    'scai-product-card': function (idx) {
      return buildCard(idx, 'scai-product-card', 'Product Card', [
        hiddenField(idx, 'type', 'scai-product-card'),
        hiddenField(idx, 'outer_html', ''),
        textField(idx, '[badge]', 'Badge', ''),
        textField(idx, '[name]', 'Product Name', ''),
        textField(idx, '[rating]', 'Rating (e.g. 4.8)', ''),
        textField(idx, '[price]', 'Price', ''),
        textareaField(idx, '[description]', 'Description', '', 3),
        textField(idx, '[cta_text]', 'Button Text', ''),
        textField(idx, '[cta_url]', 'Button URL', ''),
        textField(idx, '[image_src]', 'Image URL', '')
      ]);
    },
    'scai-service-info-box': function (idx) {
      return buildCard(idx, 'scai-service-info-box', 'Service Info', [
        hiddenField(idx, 'type', 'scai-service-info-box'),
        hiddenField(idx, 'outer_html', ''),
        textField(idx, '[header]', 'Section Header', ''),
        serviceInfoRepeater(idx, [])
      ]);
    },
    'scai-why-local-section': function (idx) {
      return buildCard(idx, 'scai-why-local-section', 'Why Choose Local', [
        hiddenField(idx, 'type', 'scai-why-local-section'),
        hiddenField(idx, 'outer_html', ''),
        textField(idx, '[title]', 'Title', ''),
        textField(idx, '[badge]', 'Badge Text', 'Local Partner'),
        textField(idx, '[image_src]', 'Image URL', ''),
        localItemsRepeater(idx, [])
      ]);
    },
    'scai-closing': function (idx) {
      return buildCard(idx, 'scai-closing', 'Closing', [
        hiddenField(idx, 'type', 'scai-closing'),
        hiddenField(idx, 'outer_html', ''),
        textField(idx, '[heading]', 'Closing Heading', ''),
        paragraphsRepeater(idx, [])
      ]);
    }
  };

  // Handle sidebar add-component clicks.
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-add-component]');
    if (!btn) return;

    var compType = btn.getAttribute('data-add-component');
    var template = componentTemplates[compType];
    if (!template) return;

    var currentCount = cardsContainer.querySelectorAll('.scai-editor-card').length;
    var cardEl = template(currentCount);

    cardsContainer.appendChild(cardEl);
    markDirty();
    updateSectionCount();

    // Highlight and scroll to new card.
    cardEl.classList.add('sce-just-added');
    cardEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
    setTimeout(function () { cardEl.classList.remove('sce-just-added'); }, 600);

    // Focus first input in new card.
    var firstInput = cardEl.querySelector('input[type="text"], textarea');
    if (firstInput) {
      setTimeout(function () { firstInput.focus(); }, 100);
    }
  });

  /* ═══════════════════════════════════════════════════════════════
     CARD / FIELD BUILDERS (for add-component)
     ═══════════════════════════════════════════════════════════════ */

  function buildCard(idx, compType, label, fieldElements) {
    var card = document.createElement('div');
    card.className = 'scai-editor-card';
    card.setAttribute('data-component-index', idx);
    card.setAttribute('data-component-type', compType);

    var header = document.createElement('div');
    header.className = 'scai-editor-card-header';
    header.innerHTML =
      '<div class="scai-editor-card-label"><span class="scai-editor-card-type">' + escapeHtml(label) + '</span></div>' +
      '<div class="scai-editor-card-controls">' +
        '<button type="button" class="scai-editor-ctrl" data-action="move-up" title="Move up">&uarr;</button>' +
        '<button type="button" class="scai-editor-ctrl" data-action="move-down" title="Move down">&darr;</button>' +
        '<button type="button" class="scai-editor-ctrl danger" data-action="delete" title="Delete section">&times;</button>' +
      '</div>';

    var body = document.createElement('div');
    body.className = 'scai-editor-card-body';
    fieldElements.forEach(function (el) { body.appendChild(el); });

    card.appendChild(header);
    card.appendChild(body);
    return card;
  }

  function hiddenField(idx, key, value) {
    var input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'components[' + idx + ']' + (key.charAt(0) === '[' ? key : '[' + key + ']');
    input.value = value;
    return input;
  }

  function textField(idx, keySuffix, labelText, value) {
    var wrap = document.createElement('div');
    wrap.className = 'scai-editor-field';
    wrap.innerHTML =
      '<label class="scai-editor-label">' + escapeHtml(labelText) + '</label>' +
      '<input type="text" name="components[' + idx + ']' + keySuffix + '" value="' + escapeAttr(value) + '" class="scai-editor-input">';
    return wrap;
  }

  function textareaField(idx, keySuffix, labelText, value, rows) {
    var wrap = document.createElement('div');
    wrap.className = 'scai-editor-field';
    wrap.innerHTML =
      '<label class="scai-editor-label">' + escapeHtml(labelText) + '</label>' +
      '<textarea name="components[' + idx + ']' + keySuffix + '" rows="' + (rows || 4) + '" class="scai-editor-textarea">' + escapeHtml(value) + '</textarea>';
    return wrap;
  }

  function paragraphsRepeater(idx, items) {
    var wrap = document.createElement('div');
    wrap.className = 'scai-editor-field';
    var prefix = 'components[' + idx + ']';
    wrap.innerHTML =
      '<label class="scai-editor-label">Paragraphs</label>' +
      '<div class="scai-editor-repeater" data-repeater="paragraphs">' +
        '<button type="button" class="scai-editor-add-btn" data-action="add-paragraph" data-prefix="' + prefix + '">+ Add Paragraph</button>' +
      '</div>';
    return wrap;
  }

  function faqRepeater(idx, items) {
    var wrap = document.createElement('div');
    wrap.className = 'scai-editor-field';
    var prefix = 'components[' + idx + ']';
    wrap.innerHTML =
      '<label class="scai-editor-label">Questions & Answers</label>' +
      '<div class="scai-editor-repeater" data-repeater="faq">' +
        '<button type="button" class="scai-editor-add-btn" data-action="add-faq" data-prefix="' + prefix + '">+ Add Question</button>' +
      '</div>';
    return wrap;
  }

  function serviceInfoRepeater(idx, items) {
    var wrap = document.createElement('div');
    wrap.className = 'scai-editor-field';
    var prefix = 'components[' + idx + ']';
    wrap.innerHTML =
      '<label class="scai-editor-label">Info Rows</label>' +
      '<div class="scai-editor-repeater" data-repeater="service-info">' +
        '<button type="button" class="scai-editor-add-btn" data-action="add-service-row" data-prefix="' + prefix + '">+ Add Row</button>' +
      '</div>';
    return wrap;
  }

  function localItemsRepeater(idx, items) {
    var wrap = document.createElement('div');
    wrap.className = 'scai-editor-field';
    var prefix = 'components[' + idx + ']';
    wrap.innerHTML =
      '<label class="scai-editor-label">Benefit Items</label>' +
      '<div class="scai-editor-repeater" data-repeater="local-items">' +
        '<button type="button" class="scai-editor-add-btn" data-action="add-local-item" data-prefix="' + prefix + '">+ Add Item</button>' +
      '</div>';
    return wrap;
  }

  /* ═══════════════════════════════════════════════════════════════
     REORDER / DELETE / REPEATER ACTIONS
     ═══════════════════════════════════════════════════════════════ */

  cardsContainer.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-action]');
    if (!btn) return;

    var action = btn.getAttribute('data-action');
    var card = btn.closest('.scai-editor-card');
    if (!card) return;

    if (action === 'move-up') {
      var prev = card.previousElementSibling;
      if (prev) {
        cardsContainer.insertBefore(card, prev);
        markDirty();
      }
    }

    if (action === 'move-down') {
      var next = card.nextElementSibling;
      if (next) {
        cardsContainer.insertBefore(next, card);
        markDirty();
      }
    }

    if (action === 'delete') {
      if (confirm('Delete this section? This cannot be undone after saving.')) {
        card.remove();
        markDirty();
        updateSectionCount();
      }
    }

    if (action === 'remove-item') {
      var item = btn.closest('.scai-editor-repeater-item');
      if (item) {
        item.remove();
        markDirty();
      }
    }

    if (action === 'add-paragraph') {
      addRepeaterItem(btn, 'paragraph');
    }

    if (action === 'add-faq') {
      addRepeaterItem(btn, 'faq');
    }

    if (action === 'add-service-row') {
      addRepeaterItem(btn, 'service-row');
    }

    if (action === 'add-local-item') {
      addRepeaterItem(btn, 'local-item');
    }
  });

  /* ═══════════════════════════════════════════════════════════════
     REPEATER: ADD ITEMS
     ═══════════════════════════════════════════════════════════════ */

  function addRepeaterItem(btn, type) {
    var repeater = btn.closest('.scai-editor-repeater');
    if (!repeater) return;

    var prefix = btn.getAttribute('data-prefix') || '';
    var item = document.createElement('div');
    item.className = 'scai-editor-repeater-item';

    var removeBtn = '<button type="button" class="scai-editor-remove-btn" data-action="remove-item" title="Remove">&times;</button>';

    if (type === 'paragraph') {
      item.innerHTML =
        '<textarea name="' + prefix + '[paragraphs][]" rows="3" class="scai-editor-textarea" placeholder="New paragraph..."></textarea>' +
        removeBtn;
    }

    if (type === 'faq') {
      item.className += ' scai-editor-faq-item';
      var existingItems = repeater.querySelectorAll('.scai-editor-faq-item');
      var newIndex = existingItems.length;
      item.innerHTML =
        '<div class="scai-editor-faq-fields">' +
          '<input type="text" name="' + prefix + '[items][' + newIndex + '][q]" class="scai-editor-input" placeholder="Question">' +
          '<textarea name="' + prefix + '[items][' + newIndex + '][a]" rows="3" class="scai-editor-textarea" placeholder="Answer"></textarea>' +
        '</div>' +
        removeBtn;
    }

    if (type === 'service-row') {
      item.className += ' scai-editor-kv-item';
      var existingRows = repeater.querySelectorAll('.scai-editor-kv-item');
      var rowIndex = existingRows.length;
      item.innerHTML =
        '<input type="text" name="' + prefix + '[rows][' + rowIndex + '][label]" class="scai-editor-input scai-editor-input-sm" placeholder="Label">' +
        '<input type="text" name="' + prefix + '[rows][' + rowIndex + '][value]" class="scai-editor-input" placeholder="Value">' +
        removeBtn;
    }

    if (type === 'local-item') {
      item.innerHTML =
        '<input type="text" name="' + prefix + '[items][]" class="scai-editor-input" placeholder="Benefit">' +
        removeBtn;
    }

    // Insert before the add button.
    repeater.insertBefore(item, btn);
    markDirty();

    // Focus the first input.
    var firstInput = item.querySelector('input, textarea');
    if (firstInput) firstInput.focus();
  }

  /* ═══════════════════════════════════════════════════════════════
     IMAGE PREVIEW
     ═══════════════════════════════════════════════════════════════ */

  form.addEventListener('input', function (e) {
    if (!e.target.hasAttribute('data-image-url')) return;

    var url = e.target.value;
    var field = e.target.closest('.scai-editor-image-field');
    if (!field) return;

    var preview = field.querySelector('[data-preview]');
    if (!preview) return;

    if (preview.tagName === 'IMG') {
      preview.src = url || '';
    }
  });

  /* ═══════════════════════════════════════════════════════════════
     SAVE EDITOR (AJAX)
     ═══════════════════════════════════════════════════════════════ */

  // Save button is outside the form (in the top bar), so listen on click.
  if (saveBtn) {
    saveBtn.addEventListener('click', function () {
      doSave();
    });
  }

  // Also support form submit (e.g. if someone hits Enter).
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    doSave();
  });

  function doSave() {
    if (!saveBtn) return;

    var originalText = saveBtn.innerHTML;
    saveBtn.innerHTML = '<span class="scai-spinner"></span> Saving...';
    saveBtn.disabled = true;

    // Collect component data from the DOM in order.
    var cards = cardsContainer.querySelectorAll('.scai-editor-card');
    var formData = new FormData();
    formData.append('action', 'scai_save_editor');
    formData.append('nonce', scaiEditor.nonce);
    formData.append('post_id', scaiEditor.postId);

    cards.forEach(function (card, cardIndex) {
      var inputs = card.querySelectorAll('input, textarea, select');
      inputs.forEach(function (input) {
        var name = input.name;
        if (!name) return;

        // Rewrite the component index to match the current DOM order.
        var reindexed = name.replace(/^components\[\d+\]/, 'components[' + cardIndex + ']');
        formData.append(reindexed, input.value);
      });
    });

    fetch(scaiEditor.ajaxUrl, {
      method: 'POST',
      body: formData,
      credentials: 'same-origin',
    })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        saveBtn.innerHTML = originalText;
        saveBtn.disabled = false;
        if (res.success) {
          markClean();
          showNotice('success', res.data.message || 'Article saved.');
        } else {
          showNotice('error', (res.data && res.data.message) || 'Save failed.');
        }
      })
      .catch(function () {
        saveBtn.innerHTML = originalText;
        saveBtn.disabled = false;
        showNotice('error', 'Network error — please try again.');
      });
  }

  /* ═══════════════════════════════════════════════════════════════
     HELPERS
     ═══════════════════════════════════════════════════════════════ */

  function updateSectionCount() {
    var counter = document.getElementById('sce-stat-sections');
    if (counter) {
      counter.textContent = cardsContainer.querySelectorAll('.scai-editor-card').length;
    }
  }

  function showNotice(type, message) {
    // Remove existing notices.
    document.querySelectorAll('.scai-notice').forEach(function (n) { n.remove(); });

    var notice = document.createElement('div');
    notice.className = 'scai-notice scai-notice-' + type;
    notice.textContent = message;
    document.body.appendChild(notice);

    setTimeout(function () {
      if (notice.parentNode) notice.parentNode.removeChild(notice);
    }, 4000);
  }

  function escapeHtml(str) {
    var div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  }

  function escapeAttr(str) {
    return (str || '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
})();
