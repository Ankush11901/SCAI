<?php
/**
 * Plugin Name: SCAI Connector
 * Plugin URI:  https://github.com/your-org/scai-renderer
 * Description: Connects your WordPress site to SEO Content AI — imports articles with consistent styling, custom design variations, and full theme isolation.
 * Version:     1.0.0
 * Author:      SCAI
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: scai-renderer
 * Requires at least: 5.9
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SCAI_RENDERER_VERSION', '1.0.0' );
define( 'SCAI_RENDERER_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SCAI_RENDERER_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/* ─── Includes ─────────────────────────────────────────────────────── */

require_once SCAI_RENDERER_PLUGIN_DIR . 'includes/class-scai-rest.php';
require_once SCAI_RENDERER_PLUGIN_DIR . 'includes/class-scai-admin.php';
require_once SCAI_RENDERER_PLUGIN_DIR . 'includes/class-scai-ajax.php';
require_once SCAI_RENDERER_PLUGIN_DIR . 'includes/class-scai-editor.php';
require_once SCAI_RENDERER_PLUGIN_DIR . 'includes/class-scai-editor-ajax.php';

/* ─── Activation / Deactivation ───────────────────────────────────── */

register_activation_hook( __FILE__, 'scai_renderer_activate' );
register_deactivation_hook( __FILE__, 'scai_renderer_deactivate' );

function scai_renderer_activate() {
	update_option( 'scai_plugin_version', SCAI_RENDERER_VERSION );
}

function scai_renderer_deactivate() {
	// Clean up transients created by handshake flow.
	global $wpdb;
	$wpdb->query(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_scai_handshake_%' OR option_name LIKE '_transient_timeout_scai_handshake_%'"
	);
}

/* ─── Register Gutenberg Block ────────────────────────────────────── */

add_action( 'init', 'scai_renderer_register_block' );

function scai_renderer_register_block() {
	register_block_type( SCAI_RENDERER_PLUGIN_DIR . 'block.json' );
}

/* ─── Enqueue Frontend CSS + Inline Style Overrides ──────────────── */

add_action( 'wp_enqueue_scripts', 'scai_renderer_enqueue_styles' );

function scai_renderer_enqueue_styles() {
	if ( ! is_singular() ) {
		return;
	}

	$post = get_post();
	if ( ! $post || ! has_block( 'scai/article', $post ) ) {
		return;
	}

	wp_enqueue_style(
		'scai-article',
		SCAI_RENDERER_PLUGIN_URL . 'assets/scai-article.css',
		array(),
		SCAI_RENDERER_VERSION
	);

	// Inject saved styling overrides as CSS custom properties.
	$styling = get_option( SCAI_Admin::OPTION_STYLE, array() );
	$css = '';

	$overrides = array();
	if ( ! empty( $styling['text_color'] ) )    $overrides[] = '--scai-text-color: '    . esc_attr( $styling['text_color'] );
	if ( ! empty( $styling['heading_color'] ) )  $overrides[] = '--scai-heading-color: ' . esc_attr( $styling['heading_color'] );
	if ( ! empty( $styling['bg_color'] ) )       $overrides[] = '--scai-bg-color: '      . esc_attr( $styling['bg_color'] );
	if ( ! empty( $styling['link_color'] ) )     $overrides[] = '--scai-link-color: '    . esc_attr( $styling['link_color'] );
	if ( ! empty( $styling['heading_font'] ) )   $overrides[] = '--scai-heading-font: "' . esc_attr( $styling['heading_font'] ) . '", sans-serif';
	if ( ! empty( $styling['body_font'] ) )      $overrides[] = '--scai-body-font: "'    . esc_attr( $styling['body_font'] ) . '", serif';

	if ( ! empty( $overrides ) ) {
		$css = '.scai-wrapper { ' . implode( '; ', $overrides ) . '; }';
		wp_add_inline_style( 'scai-article', $css );
	}

	// Enqueue Google Fonts if custom fonts are set.
	$fonts_to_load = array();
	if ( ! empty( $styling['heading_font'] ) && $styling['heading_font'] !== 'Georgia' ) {
		$fonts_to_load[] = $styling['heading_font'];
	}
	if ( ! empty( $styling['body_font'] ) && $styling['body_font'] !== 'Georgia' ) {
		$fonts_to_load[] = $styling['body_font'];
	}
	$fonts_to_load = array_unique( $fonts_to_load );

	if ( ! empty( $fonts_to_load ) ) {
		$families = array_map( function ( $f ) {
			return str_replace( ' ', '+', $f ) . ':wght@400;500;600;700';
		}, $fonts_to_load );
		$url = 'https://fonts.googleapis.com/css2?family=' . implode( '&family=', $families ) . '&display=swap';
		wp_enqueue_style( 'scai-google-fonts', $url, array(), null );
	}
}

/* ─── Enqueue Admin CSS + JS ──────────────────────────────────────── */

add_action( 'admin_enqueue_scripts', 'scai_renderer_enqueue_admin' );

function scai_renderer_enqueue_admin( $hook ) {
	// Only load on our plugin pages.
	$our_pages = array(
		'toplevel_page_scai-connector',
		'scai-connector_page_scai-connector-articles',
		'scai-connector_page_scai-connector-styling',
		'scai-connector_page_scai-connector-settings',
		'scai-connector_page_scai-editor',
	);

	if ( ! in_array( $hook, $our_pages, true ) ) {
		return;
	}

	// Load Inter font
	wp_enqueue_style(
		'scai-admin-font',
		'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap',
		array(),
		null
	);

	wp_enqueue_style(
		'scai-admin',
		SCAI_RENDERER_PLUGIN_URL . 'assets/scai-admin.css',
		array( 'scai-admin-font' ),
		SCAI_RENDERER_VERSION
	);

	wp_enqueue_script(
		'scai-admin',
		SCAI_RENDERER_PLUGIN_URL . 'assets/scai-admin.js',
		array(),
		SCAI_RENDERER_VERSION,
		true
	);

	wp_localize_script( 'scai-admin', 'scaiAdmin', array(
		'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'scai_admin_nonce' ),
	) );

	// Editor-specific assets.
	if ( $hook === 'scai-connector_page_scai-editor' ) {
		wp_enqueue_style(
			'scai-editor',
			SCAI_RENDERER_PLUGIN_URL . 'assets/scai-editor.css',
			array( 'scai-admin' ),
			SCAI_RENDERER_VERSION
		);

		wp_enqueue_script(
			'scai-editor',
			SCAI_RENDERER_PLUGIN_URL . 'assets/scai-editor.js',
			array(),
			SCAI_RENDERER_VERSION,
			true
		);

		$post_id = isset( $_GET['post_id'] ) ? absint( $_GET['post_id'] ) : 0;
		wp_localize_script( 'scai-editor', 'scaiEditor', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'scai_save_editor' ),
			'postId'  => $post_id,
		) );
	}
}

/* ─── Initialise REST + Admin + AJAX ─────────────────────────────── */

add_action( 'rest_api_init', array( 'SCAI_REST', 'register_routes' ) );
add_action( 'admin_menu',    array( 'SCAI_Admin', 'register_menu' ) );

SCAI_Ajax::register();
SCAI_Editor_Ajax::register();
