<?php
/**
 * SCAI Connector — Section-Level Article Editor.
 *
 * Parses article HTML by data-component attributes,
 * renders structured form fields, and rebuilds HTML on save.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SCAI_Editor {

	/**
	 * Components available to add via the sidebar.
	 */
	private static $addable_components = array(
		'scai-section'           => array( 'label' => 'Content Section', 'icon' => 'section', 'desc' => 'Heading + paragraphs' ),
		'scai-faq-section'       => array( 'label' => 'FAQ',            'icon' => 'faq',     'desc' => 'Questions & answers' ),
		'scai-product-card'      => array( 'label' => 'Product Card',   'icon' => 'product', 'desc' => 'Product showcase' ),
		'scai-service-info-box'  => array( 'label' => 'Service Info',   'icon' => 'info',    'desc' => 'Key/value info rows' ),
		'scai-why-local-section' => array( 'label' => 'Why Local',      'icon' => 'local',   'desc' => 'Local benefits list' ),
		'scai-closing'           => array( 'label' => 'Closing',        'icon' => 'closing',  'desc' => 'Final section' ),
	);

	public static function render_editor( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post || strpos( $post->post_content, 'wp:scai/article' ) === false ) {
			echo '<div class="wrap scai-wrap"><div class="scai-panel"><div class="scai-panel-content">';
			echo '<p style="color:#a3a3a3;padding:40px 24px;">Article not found or not an SCAI article.</p>';
			echo '<a href="' . esc_url( admin_url( 'admin.php?page=scai-connector-articles' ) ) . '" class="scai-btn scai-btn-secondary">&larr; Back to Articles</a>';
			echo '</div></div></div>';
			return;
		}

		$components = self::parse_article( $post->post_content );
		$article_type = self::extract_article_meta( $post->post_content, 'data-article-type' );
		$variation = self::extract_article_meta( $post->post_content, 'data-variation' );
		$word_count = str_word_count( wp_strip_all_tags( $post->post_content ) );
		$comp_count = count( $components );

		?>
		<div class="wrap scai-wrap scai-editor-wrap">

			<!-- ═══ FIXED TOP BAR ═══ -->
			<div class="sce-topbar">
				<div class="sce-topbar-left">
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=scai-connector-articles' ) ); ?>" class="sce-topbar-back" title="Back to Articles">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><polyline points="15 18 9 12 15 6"/></svg>
					</a>
					<div class="sce-topbar-divider"></div>
					<div class="sce-topbar-title">
						<span class="sce-topbar-label">Editing</span>
						<span class="sce-topbar-name"><?php echo esc_html( wp_trim_words( $post->post_title, 8, '...' ) ); ?></span>
					</div>
				</div>
				<div class="sce-topbar-center">
					<div class="sce-topbar-unsaved" id="scai-unsaved-bar" style="display:none;">
						<span class="sce-unsaved-dot"></span>
						Unsaved changes
					</div>
				</div>
				<div class="sce-topbar-right">
					<div class="sce-topbar-meta">
						<?php if ( $article_type ) : ?>
							<span class="scai-badge scai-badge-<?php echo esc_attr( $article_type ); ?>"><?php echo esc_html( ucfirst( $article_type ) ); ?></span>
						<?php endif; ?>
						<span class="scai-badge scai-badge-<?php echo esc_attr( $post->post_status === 'publish' ? 'published' : 'draft' ); ?>">
							<?php echo esc_html( $post->post_status === 'publish' ? 'Published' : 'Draft' ); ?>
						</span>
					</div>
					<button type="button" class="sce-btn-save" id="scai-save-editor">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polyline points="20 6 9 17 4 12"/></svg>
						Save
					</button>
				</div>
			</div>

			<!-- ═══ MAIN LAYOUT ═══ -->
			<div class="sce-layout">

				<!-- ═══ LEFT SIDEBAR — Add Components ═══ -->
				<aside class="sce-sidebar" id="sce-sidebar">
					<div class="sce-sidebar-header">
						<h3 class="sce-sidebar-title">Components</h3>
						<button type="button" class="sce-sidebar-toggle" id="sce-sidebar-toggle" title="Toggle sidebar">
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/></svg>
						</button>
					</div>
					<p class="sce-sidebar-hint">Click to add a section to the article</p>
					<div class="sce-sidebar-components">
						<?php foreach ( self::$addable_components as $comp_type => $meta ) : ?>
							<button type="button" class="sce-component-btn" data-add-component="<?php echo esc_attr( $comp_type ); ?>">
								<span class="sce-component-icon"><?php echo self::get_component_svg( $meta['icon'] ); ?></span>
								<span class="sce-component-info">
									<span class="sce-component-name"><?php echo esc_html( $meta['label'] ); ?></span>
									<span class="sce-component-desc"><?php echo esc_html( $meta['desc'] ); ?></span>
								</span>
							</button>
						<?php endforeach; ?>
					</div>
					<div class="sce-sidebar-stats">
						<div class="sce-stat-row"><span>Sections</span><span class="sce-stat-val" id="sce-stat-sections"><?php echo esc_html( $comp_count ); ?></span></div>
						<div class="sce-stat-row"><span>Words</span><span class="sce-stat-val"><?php echo esc_html( number_format( $word_count ) ); ?></span></div>
						<?php if ( $variation ) : ?>
							<div class="sce-stat-row"><span>Variation</span><span class="sce-stat-val"><?php echo esc_html( $variation ); ?></span></div>
						<?php endif; ?>
					</div>
				</aside>

				<!-- ═══ CENTER — Editor Canvas ═══ -->
				<main class="sce-canvas">
					<form id="scai-editor-form" data-post-id="<?php echo esc_attr( $post_id ); ?>">
						<?php wp_nonce_field( 'scai_save_editor', 'scai_editor_nonce' ); ?>

						<div class="scai-editor-cards" id="scai-editor-cards">
							<?php
							foreach ( $components as $index => $comp ) {
								self::render_component_card( $comp, $index );
							}
							?>
						</div>
					</form>
				</main>

			</div><!-- .sce-layout -->
		</div><!-- .scai-editor-wrap -->
		<?php
	}

	/* ─── HTML Parser ─────────────────────────────────────────────── */

	/**
	 * Parse article HTML into an ordered array of component descriptors.
	 */
	public static function parse_article( $post_content ) {
		// Extract the HTML from the Gutenberg block comment.
		$html = self::extract_block_html( $post_content );
		if ( ! $html ) {
			return array();
		}

		// Parse with DOMDocument.
		$doc = new DOMDocument();
		libxml_use_internal_errors( true );
		$doc->loadHTML( '<?xml encoding="UTF-8">' . $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();

		$components = array();
		$index = 0;

		// Find the wrapper element.
		// Export wraps in <div class="wp-block-scai-article scai-wrapper">.
		// Fallback to <article> for raw HTML (e.g. standalone previews).
		$wrapper = null;
		$xpath = new DOMXPath( $doc );

		// Try the Gutenberg wrapper div first.
		$wrappers = $xpath->query( '//div[contains(@class,"wp-block-scai-article")]' );
		if ( $wrappers->length > 0 ) {
			$wrapper = $wrappers->item( 0 );
		}

		// Fallback: try <article> tag.
		if ( ! $wrapper ) {
			$articles = $doc->getElementsByTagName( 'article' );
			if ( $articles->length > 0 ) {
				$wrapper = $articles->item( 0 );
			}
		}

		// Last resort: walk from the document root.
		if ( ! $wrapper ) {
			$wrapper = $doc->documentElement ?: $doc;
		}

		// Walk children for data-component.
		self::walk_for_components( $wrapper, $doc, $components, $index );

		return $components;
	}

	/**
	 * Walk DOM tree to find elements with data-component attribute.
	 */
	private static function walk_for_components( $parent, $doc, &$components, &$index ) {
		foreach ( $parent->childNodes as $node ) {
			if ( $node->nodeType !== XML_ELEMENT_NODE ) {
				continue;
			}

			$comp_type = $node->getAttribute( 'data-component' );

			if ( $comp_type ) {
				$content = self::extract_component_content( $comp_type, $node, $doc );
				$components[] = array(
					'type'       => $comp_type,
					'index'      => $index,
					'content'    => $content,
					'outer_html' => self::get_outer_html( $node, $doc ),
				);
				$index++;
			} else {
				// Check children (e.g. wrapper divs with class="scai-component").
				self::walk_for_components( $node, $doc, $components, $index );
			}
		}
	}

	/**
	 * Extract structured content from a component node based on its type.
	 */
	private static function extract_component_content( $type, $node, $doc ) {
		switch ( $type ) {
			case 'scai-h1':
				return self::extract_h1( $node, $doc );
			case 'scai-featured-image':
				return self::extract_featured_image( $node, $doc );
			case 'scai-overview':
				return self::extract_overview( $node, $doc );
			case 'scai-table-of-contents':
				return array( 'auto' => true );
			case 'scai-section':
				return self::extract_section( $node, $doc );
			case 'scai-faq-section':
				return self::extract_faq( $node, $doc );
			case 'scai-product-card':
				return self::extract_product_card( $node, $doc );
			case 'scai-service-info-box':
				return self::extract_service_info( $node, $doc );
			case 'scai-why-local-section':
				return self::extract_why_local( $node, $doc );
			case 'scai-closing':
				return self::extract_closing( $node, $doc );
			default:
				return self::extract_generic( $node, $doc );
		}
	}

	/* ─── Component Extractors ────────────────────────────────────── */

	private static function extract_h1( $node, $doc ) {
		$h1 = $node->getElementsByTagName( 'h1' )->item( 0 );
		return array(
			'title' => $h1 ? $h1->textContent : '',
		);
	}

	private static function extract_featured_image( $node, $doc ) {
		$img = $node->getElementsByTagName( 'img' )->item( 0 );
		$figcaption = $node->getElementsByTagName( 'figcaption' )->item( 0 );
		return array(
			'src'     => $img ? $img->getAttribute( 'src' ) : '',
			'alt'     => $img ? $img->getAttribute( 'alt' ) : '',
			'caption' => $figcaption ? $figcaption->textContent : '',
		);
	}

	private static function extract_overview( $node, $doc ) {
		$paragraphs = array();
		$ps = $node->getElementsByTagName( 'p' );
		for ( $i = 0; $i < $ps->length; $i++ ) {
			$paragraphs[] = $ps->item( $i )->textContent;
		}
		return array( 'paragraphs' => $paragraphs );
	}

	private static function extract_section( $node, $doc ) {
		$h2 = $node->getElementsByTagName( 'h2' )->item( 0 );
		$heading = $h2 ? $h2->textContent : '';
		$section_id = $node->getAttribute( 'id' );

		// Get image if present.
		$image_src = '';
		$image_alt = '';
		$image_caption = '';
		$figures = $node->getElementsByTagName( 'figure' );
		if ( $figures->length > 0 ) {
			$fig = $figures->item( 0 );
			$img = $fig->getElementsByTagName( 'img' )->item( 0 );
			$figcap = $fig->getElementsByTagName( 'figcaption' )->item( 0 );
			if ( $img ) {
				$image_src = $img->getAttribute( 'src' );
				$image_alt = $img->getAttribute( 'alt' );
			}
			if ( $figcap ) {
				$image_caption = $figcap->textContent;
			}
		}

		// Get paragraphs.
		$paragraphs = array();
		$ps = $node->getElementsByTagName( 'p' );
		for ( $i = 0; $i < $ps->length; $i++ ) {
			$p = $ps->item( $i );
			// Skip figcaption paragraph contents.
			if ( $p->parentNode && $p->parentNode->nodeName === 'figcaption' ) {
				continue;
			}
			$text = $p->textContent;
			if ( ! empty( trim( $text ) ) ) {
				$paragraphs[] = $text;
			}
		}

		return array(
			'heading'       => $heading,
			'section_id'    => $section_id,
			'image_src'     => $image_src,
			'image_alt'     => $image_alt,
			'image_caption' => $image_caption,
			'paragraphs'    => $paragraphs,
		);
	}

	private static function extract_faq( $node, $doc ) {
		$h2 = $node->getElementsByTagName( 'h2' )->item( 0 );
		$title = $h2 ? $h2->textContent : 'Frequently Asked Questions';

		$items = array();
		$h3s = $node->getElementsByTagName( 'h3' );
		for ( $i = 0; $i < $h3s->length; $i++ ) {
			$q = $h3s->item( $i )->textContent;
			// The answer is the next sibling <p>.
			$a = '';
			$sibling = $h3s->item( $i )->nextSibling;
			while ( $sibling ) {
				if ( $sibling->nodeType === XML_ELEMENT_NODE && $sibling->nodeName === 'p' ) {
					$a = $sibling->textContent;
					break;
				}
				$sibling = $sibling->nextSibling;
			}
			$items[] = array( 'q' => $q, 'a' => $a );
		}

		return array( 'title' => $title, 'items' => $items );
	}

	private static function extract_product_card( $node, $doc ) {
		$name = '';
		$rating = '';
		$price = '';
		$description = '';
		$cta_text = '';
		$cta_url = '';
		$image_src = '';
		$badge = '';

		// Name.
		$xpath = new DOMXPath( $doc );
		$titles = $xpath->query( './/*[contains(@class,"scai-pc-title")]', $node );
		if ( $titles->length > 0 ) {
			$name = $titles->item( 0 )->textContent;
		}

		// Rating.
		$rating_nums = $xpath->query( './/*[contains(@class,"scai-pc-rating-num")]', $node );
		if ( $rating_nums->length > 0 ) {
			$rating = $rating_nums->item( 0 )->textContent;
		}

		// Price.
		$prices = $xpath->query( './/*[contains(@class,"scai-pc-price")]', $node );
		if ( $prices->length > 0 ) {
			$price = $prices->item( 0 )->textContent;
		}

		// Description.
		$descs = $xpath->query( './/*[contains(@class,"scai-pc-desc")]', $node );
		if ( $descs->length > 0 ) {
			$description = $descs->item( 0 )->textContent;
		}

		// CTA.
		$ctas = $xpath->query( './/*[contains(@class,"scai-pc-cta")]', $node );
		if ( $ctas->length > 0 ) {
			$cta_text = $ctas->item( 0 )->textContent;
			$cta_url = $ctas->item( 0 )->getAttribute( 'href' );
		}

		// Image.
		$imgs = $xpath->query( './/img', $node );
		if ( $imgs->length > 0 ) {
			$image_src = $imgs->item( 0 )->getAttribute( 'src' );
		}

		// Badge.
		$badges = $xpath->query( './/*[contains(@class,"scai-pc-badge")]', $node );
		if ( $badges->length > 0 ) {
			$badge = $badges->item( 0 )->textContent;
		}

		return array(
			'name'        => $name,
			'rating'      => $rating,
			'price'       => $price,
			'description' => $description,
			'cta_text'    => $cta_text,
			'cta_url'     => $cta_url,
			'image_src'   => $image_src,
			'badge'       => $badge,
		);
	}

	private static function extract_service_info( $node, $doc ) {
		$xpath = new DOMXPath( $doc );
		$header = '';
		$headers = $xpath->query( './/*[contains(@class,"scai-svc-header")]', $node );
		if ( $headers->length > 0 ) {
			$header = $headers->item( 0 )->textContent;
		}

		$rows = array();
		$row_els = $xpath->query( './/*[contains(@class,"scai-svc-row")]', $node );
		for ( $i = 0; $i < $row_els->length; $i++ ) {
			$row = $row_els->item( $i );
			$label = '';
			$value = '';
			$labels = $xpath->query( './/*[contains(@class,"scai-svc-label")]', $row );
			$values = $xpath->query( './/*[contains(@class,"scai-svc-value")]', $row );
			if ( $labels->length > 0 ) $label = $labels->item( 0 )->textContent;
			if ( $values->length > 0 ) $value = $values->item( 0 )->textContent;
			$rows[] = array( 'label' => $label, 'value' => $value );
		}

		return array( 'header' => $header, 'rows' => $rows );
	}

	private static function extract_why_local( $node, $doc ) {
		$xpath = new DOMXPath( $doc );

		$title = '';
		$titles = $xpath->query( './/*[contains(@class,"scai-local-title")]', $node );
		if ( $titles->length > 0 ) {
			$title = $titles->item( 0 )->textContent;
		}

		$badge = '';
		$badges = $xpath->query( './/*[contains(@class,"scai-local-badge")]', $node );
		if ( $badges->length > 0 ) {
			$badge = $badges->item( 0 )->textContent;
		}

		$items = array();
		$lis = $xpath->query( './/*[contains(@class,"scai-local-list")]/li', $node );
		for ( $i = 0; $i < $lis->length; $i++ ) {
			$items[] = $lis->item( $i )->textContent;
		}

		$image_src = '';
		$imgs = $xpath->query( './/img', $node );
		if ( $imgs->length > 0 ) {
			$image_src = $imgs->item( 0 )->getAttribute( 'src' );
		}

		return array(
			'title'     => $title,
			'badge'     => $badge,
			'items'     => $items,
			'image_src' => $image_src,
		);
	}

	private static function extract_closing( $node, $doc ) {
		$h2 = $node->getElementsByTagName( 'h2' )->item( 0 );
		$heading = $h2 ? $h2->textContent : '';

		$paragraphs = array();
		$ps = $node->getElementsByTagName( 'p' );
		for ( $i = 0; $i < $ps->length; $i++ ) {
			$text = $ps->item( $i )->textContent;
			if ( ! empty( trim( $text ) ) ) {
				$paragraphs[] = $text;
			}
		}

		return array( 'heading' => $heading, 'paragraphs' => $paragraphs );
	}

	private static function extract_generic( $node, $doc ) {
		return array( 'html' => self::get_inner_html( $node, $doc ) );
	}

	/* ─── Form Renderer ───────────────────────────────────────────── */

	/**
	 * Render a single component as an editor card.
	 */
	private static function render_component_card( $comp, $index ) {
		$type = $comp['type'];
		$content = $comp['content'];
		$label = self::get_component_label( $type );

		?>
		<div class="scai-editor-card" data-component-index="<?php echo esc_attr( $index ); ?>" data-component-type="<?php echo esc_attr( $type ); ?>">
			<div class="scai-editor-card-header">
				<div class="scai-editor-card-label">
					<span class="scai-editor-card-icon"><?php echo self::get_card_icon( $type ); ?></span>
					<span class="scai-editor-card-type"><?php echo esc_html( $label ); ?></span>
				</div>
				<div class="scai-editor-card-controls">
					<?php if ( $type !== 'scai-h1' && $type !== 'scai-table-of-contents' ) : ?>
						<button type="button" class="scai-editor-ctrl" data-action="move-up" title="Move up">&uarr;</button>
						<button type="button" class="scai-editor-ctrl" data-action="move-down" title="Move down">&darr;</button>
						<button type="button" class="scai-editor-ctrl danger" data-action="delete" title="Delete section">&times;</button>
					<?php endif; ?>
				</div>
			</div>
			<div class="scai-editor-card-body">
				<input type="hidden" name="components[<?php echo esc_attr( $index ); ?>][type]" value="<?php echo esc_attr( $type ); ?>">
				<input type="hidden" name="components[<?php echo esc_attr( $index ); ?>][outer_html]" value="<?php echo esc_attr( $comp['outer_html'] ); ?>">
				<?php self::render_component_fields( $type, $content, $index ); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render type-specific form fields.
	 */
	private static function render_component_fields( $type, $content, $index ) {
		$prefix = "components[{$index}]";

		switch ( $type ) {
			case 'scai-h1':
				self::render_text_field( $prefix . '[title]', 'Article Title', $content['title'], 'scai-editor-input-large' );
				break;

			case 'scai-featured-image':
				self::render_image_field( $prefix, $content );
				break;

			case 'scai-overview':
				self::render_paragraphs_field( $prefix, 'Overview Paragraphs', $content['paragraphs'] );
				break;

			case 'scai-table-of-contents':
				echo '<p class="scai-editor-info">Table of Contents is auto-generated from section headings. No editing needed.</p>';
				break;

			case 'scai-section':
				self::render_section_fields( $prefix, $content );
				break;

			case 'scai-faq-section':
				self::render_faq_fields( $prefix, $content );
				break;

			case 'scai-product-card':
				self::render_product_card_fields( $prefix, $content );
				break;

			case 'scai-service-info-box':
				self::render_service_info_fields( $prefix, $content );
				break;

			case 'scai-why-local-section':
				self::render_why_local_fields( $prefix, $content );
				break;

			case 'scai-closing':
				self::render_closing_fields( $prefix, $content );
				break;

			default:
				self::render_generic_fields( $prefix, $content );
				break;
		}
	}

	/* ─── Field Renderers ─────────────────────────────────────────── */

	private static function render_text_field( $name, $label, $value, $class = '' ) {
		?>
		<div class="scai-editor-field">
			<label class="scai-editor-label"><?php echo esc_html( $label ); ?></label>
			<input type="text" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" class="scai-editor-input <?php echo esc_attr( $class ); ?>">
		</div>
		<?php
	}

	private static function render_textarea_field( $name, $label, $value, $rows = 4 ) {
		?>
		<div class="scai-editor-field">
			<label class="scai-editor-label"><?php echo esc_html( $label ); ?></label>
			<textarea name="<?php echo esc_attr( $name ); ?>" rows="<?php echo esc_attr( $rows ); ?>" class="scai-editor-textarea"><?php echo esc_textarea( $value ); ?></textarea>
		</div>
		<?php
	}

	private static function render_image_field( $prefix, $content ) {
		?>
		<div class="scai-editor-field scai-editor-image-field">
			<label class="scai-editor-label">Image</label>
			<div class="scai-editor-image-row">
				<?php if ( ! empty( $content['src'] ) ) : ?>
					<img src="<?php echo esc_url( $content['src'] ); ?>" alt="" class="scai-editor-image-preview" data-preview>
				<?php else : ?>
					<div class="scai-editor-image-preview scai-editor-image-empty" data-preview>No image</div>
				<?php endif; ?>
				<div class="scai-editor-image-inputs">
					<input type="text" name="<?php echo esc_attr( $prefix ); ?>[src]" value="<?php echo esc_attr( $content['src'] ); ?>" class="scai-editor-input" placeholder="Image URL" data-image-url>
					<input type="text" name="<?php echo esc_attr( $prefix ); ?>[alt]" value="<?php echo esc_attr( $content['alt'] ); ?>" class="scai-editor-input" placeholder="Alt text">
					<?php if ( isset( $content['caption'] ) ) : ?>
						<input type="text" name="<?php echo esc_attr( $prefix ); ?>[caption]" value="<?php echo esc_attr( $content['caption'] ); ?>" class="scai-editor-input" placeholder="Caption">
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}

	private static function render_paragraphs_field( $prefix, $label, $paragraphs ) {
		?>
		<div class="scai-editor-field">
			<label class="scai-editor-label"><?php echo esc_html( $label ); ?></label>
			<div class="scai-editor-repeater" data-repeater="paragraphs">
				<?php foreach ( $paragraphs as $pi => $p ) : ?>
					<div class="scai-editor-repeater-item">
						<textarea name="<?php echo esc_attr( $prefix ); ?>[paragraphs][]" rows="3" class="scai-editor-textarea"><?php echo esc_textarea( $p ); ?></textarea>
						<button type="button" class="scai-editor-remove-btn" data-action="remove-item" title="Remove">&times;</button>
					</div>
				<?php endforeach; ?>
				<button type="button" class="scai-editor-add-btn" data-action="add-paragraph" data-prefix="<?php echo esc_attr( $prefix ); ?>">+ Add Paragraph</button>
			</div>
		</div>
		<?php
	}

	private static function render_section_fields( $prefix, $content ) {
		self::render_text_field( $prefix . '[heading]', 'Section Heading', $content['heading'] );

		if ( ! empty( $content['section_id'] ) ) {
			echo '<input type="hidden" name="' . esc_attr( $prefix ) . '[section_id]" value="' . esc_attr( $content['section_id'] ) . '">';
		}

		if ( ! empty( $content['image_src'] ) ) {
			?>
			<div class="scai-editor-field scai-editor-image-field">
				<label class="scai-editor-label">Section Image</label>
				<div class="scai-editor-image-row">
					<img src="<?php echo esc_url( $content['image_src'] ); ?>" alt="" class="scai-editor-image-preview" data-preview>
					<div class="scai-editor-image-inputs">
						<input type="text" name="<?php echo esc_attr( $prefix ); ?>[image_src]" value="<?php echo esc_attr( $content['image_src'] ); ?>" class="scai-editor-input" placeholder="Image URL" data-image-url>
						<input type="text" name="<?php echo esc_attr( $prefix ); ?>[image_alt]" value="<?php echo esc_attr( $content['image_alt'] ); ?>" class="scai-editor-input" placeholder="Alt text">
						<input type="text" name="<?php echo esc_attr( $prefix ); ?>[image_caption]" value="<?php echo esc_attr( $content['image_caption'] ); ?>" class="scai-editor-input" placeholder="Caption">
					</div>
				</div>
			</div>
			<?php
		}

		self::render_paragraphs_field( $prefix, 'Paragraphs', $content['paragraphs'] );
	}

	private static function render_faq_fields( $prefix, $content ) {
		self::render_text_field( $prefix . '[title]', 'FAQ Section Title', $content['title'] );
		?>
		<div class="scai-editor-field">
			<label class="scai-editor-label">Questions & Answers</label>
			<div class="scai-editor-repeater" data-repeater="faq">
				<?php foreach ( $content['items'] as $fi => $item ) : ?>
					<div class="scai-editor-repeater-item scai-editor-faq-item">
						<div class="scai-editor-faq-fields">
							<input type="text" name="<?php echo esc_attr( $prefix ); ?>[items][<?php echo esc_attr( $fi ); ?>][q]" value="<?php echo esc_attr( $item['q'] ); ?>" class="scai-editor-input" placeholder="Question">
							<textarea name="<?php echo esc_attr( $prefix ); ?>[items][<?php echo esc_attr( $fi ); ?>][a]" rows="3" class="scai-editor-textarea" placeholder="Answer"><?php echo esc_textarea( $item['a'] ); ?></textarea>
						</div>
						<button type="button" class="scai-editor-remove-btn" data-action="remove-item" title="Remove">&times;</button>
					</div>
				<?php endforeach; ?>
				<button type="button" class="scai-editor-add-btn" data-action="add-faq" data-prefix="<?php echo esc_attr( $prefix ); ?>">+ Add Question</button>
			</div>
		</div>
		<?php
	}

	private static function render_product_card_fields( $prefix, $content ) {
		self::render_text_field( $prefix . '[badge]', 'Badge', $content['badge'] );
		self::render_text_field( $prefix . '[name]', 'Product Name', $content['name'] );
		self::render_text_field( $prefix . '[rating]', 'Rating (e.g. 4.8)', $content['rating'] );
		self::render_text_field( $prefix . '[price]', 'Price', $content['price'] );
		self::render_textarea_field( $prefix . '[description]', 'Description', $content['description'], 3 );
		self::render_text_field( $prefix . '[cta_text]', 'Button Text', $content['cta_text'] );
		self::render_text_field( $prefix . '[cta_url]', 'Button URL', $content['cta_url'] );
		self::render_text_field( $prefix . '[image_src]', 'Image URL', $content['image_src'] );
	}

	private static function render_service_info_fields( $prefix, $content ) {
		self::render_text_field( $prefix . '[header]', 'Section Header', $content['header'] );
		?>
		<div class="scai-editor-field">
			<label class="scai-editor-label">Info Rows</label>
			<div class="scai-editor-repeater" data-repeater="service-info">
				<?php foreach ( $content['rows'] as $ri => $row ) : ?>
					<div class="scai-editor-repeater-item scai-editor-kv-item">
						<input type="text" name="<?php echo esc_attr( $prefix ); ?>[rows][<?php echo esc_attr( $ri ); ?>][label]" value="<?php echo esc_attr( $row['label'] ); ?>" class="scai-editor-input scai-editor-input-sm" placeholder="Label">
						<input type="text" name="<?php echo esc_attr( $prefix ); ?>[rows][<?php echo esc_attr( $ri ); ?>][value]" value="<?php echo esc_attr( $row['value'] ); ?>" class="scai-editor-input" placeholder="Value">
						<button type="button" class="scai-editor-remove-btn" data-action="remove-item" title="Remove">&times;</button>
					</div>
				<?php endforeach; ?>
				<button type="button" class="scai-editor-add-btn" data-action="add-service-row" data-prefix="<?php echo esc_attr( $prefix ); ?>">+ Add Row</button>
			</div>
		</div>
		<?php
	}

	private static function render_why_local_fields( $prefix, $content ) {
		self::render_text_field( $prefix . '[title]', 'Title', $content['title'] );
		self::render_text_field( $prefix . '[badge]', 'Badge Text', $content['badge'] );
		self::render_text_field( $prefix . '[image_src]', 'Image URL', $content['image_src'] );
		?>
		<div class="scai-editor-field">
			<label class="scai-editor-label">Benefit Items</label>
			<div class="scai-editor-repeater" data-repeater="local-items">
				<?php foreach ( $content['items'] as $li => $item ) : ?>
					<div class="scai-editor-repeater-item">
						<input type="text" name="<?php echo esc_attr( $prefix ); ?>[items][]" value="<?php echo esc_attr( $item ); ?>" class="scai-editor-input" placeholder="Benefit">
						<button type="button" class="scai-editor-remove-btn" data-action="remove-item" title="Remove">&times;</button>
					</div>
				<?php endforeach; ?>
				<button type="button" class="scai-editor-add-btn" data-action="add-local-item" data-prefix="<?php echo esc_attr( $prefix ); ?>">+ Add Item</button>
			</div>
		</div>
		<?php
	}

	private static function render_closing_fields( $prefix, $content ) {
		self::render_text_field( $prefix . '[heading]', 'Closing Heading', $content['heading'] );
		self::render_paragraphs_field( $prefix, 'Closing Paragraphs', $content['paragraphs'] );
	}

	private static function render_generic_fields( $prefix, $content ) {
		?>
		<div class="scai-editor-field">
			<p class="scai-editor-info scai-editor-info-warning">This component uses advanced editing. Edit the raw HTML below carefully.</p>
			<textarea name="<?php echo esc_attr( $prefix ); ?>[html]" rows="8" class="scai-editor-textarea scai-editor-textarea-code"><?php echo esc_textarea( $content['html'] ); ?></textarea>
		</div>
		<?php
	}

	/* ─── HTML Rebuilder ──────────────────────────────────────────── */

	/**
	 * Rebuild article HTML from edited components.
	 *
	 * @param int   $post_id    The post ID.
	 * @param array $components Edited components array from the form.
	 * @return string The full post_content with Gutenberg block wrapper.
	 */
	public static function rebuild_html( $post_id, $components ) {
		$post = get_post( $post_id );
		$original_content = $post->post_content;

		// Extract the original block comment attributes and wrapper tag.
		$block_attrs = self::extract_block_attrs( $original_content );
		$wrapper_tag = self::extract_wrapper_tag( $original_content );

		// Build new components HTML.
		$parts = array();
		$section_headings = array(); // For TOC regeneration.
		$section_index = 0;

		foreach ( $components as $comp ) {
			$type = $comp['type'];

			if ( $type === 'scai-table-of-contents' ) {
				// Placeholder — we'll replace this after collecting headings.
				$parts[] = '%%TOC_PLACEHOLDER%%';
				continue;
			}

			$html = self::rebuild_component( $comp );
			$parts[] = $html;

			// Track section headings for TOC.
			if ( $type === 'scai-section' && ! empty( $comp['heading'] ) ) {
				$section_headings[] = array(
					'id'    => ! empty( $comp['section_id'] ) ? $comp['section_id'] : 'section-' . $section_index,
					'title' => $comp['heading'],
				);
				$section_index++;
			}
		}

		// Regenerate TOC.
		$toc_html = self::build_toc_html( $section_headings, $original_content );

		$body_html = implode( "\n\n", $parts );
		$body_html = str_replace( '%%TOC_PLACEHOLDER%%', $toc_html, $body_html );

		// Reconstruct using the original wrapper format.
		$block_comment = '<!-- wp:scai/article' . ( $block_attrs ? ' ' . $block_attrs : '' ) . ' -->';
		$block_end = '<!-- /wp:scai/article -->';

		// Determine closing tag from wrapper (div or article).
		$closing_tag = '</div>';
		if ( strpos( $wrapper_tag, '<article' ) === 0 ) {
			$closing_tag = '</article>';
		}

		$full_html = $block_comment . "\n" . $wrapper_tag . "\n" . $body_html . "\n" . $closing_tag . "\n" . $block_end;

		return $full_html;
	}

	/**
	 * Rebuild a single component's HTML from its edited content.
	 */
	private static function rebuild_component( $comp ) {
		$type = isset( $comp['type'] ) ? $comp['type'] : '';
		$outer = isset( $comp['outer_html'] ) ? $comp['outer_html'] : '';

		switch ( $type ) {
			case 'scai-h1':
				return self::rebuild_h1( $comp );
			case 'scai-featured-image':
				return self::rebuild_featured_image( $comp );
			case 'scai-overview':
				return self::rebuild_overview( $comp );
			case 'scai-section':
				return self::rebuild_section( $comp, $outer );
			case 'scai-faq-section':
				return self::rebuild_faq( $comp, $outer );
			case 'scai-product-card':
				// Product cards have complex variation-specific HTML — use DOM manipulation.
				return self::rebuild_from_outer( $comp, $outer );
			case 'scai-service-info-box':
				return self::rebuild_service_info( $comp, $outer );
			case 'scai-why-local-section':
				return self::rebuild_why_local( $comp, $outer );
			case 'scai-closing':
				return self::rebuild_closing( $comp );
			default:
				// Generic: use the raw HTML if provided, otherwise preserve original.
				if ( ! empty( $comp['html'] ) ) {
					return $comp['html'];
				}
				return $outer;
		}
	}

	private static function rebuild_h1( $comp ) {
		$title = esc_html( $comp['title'] );
		return "<header data-component=\"scai-h1\">\n  <h1 class=\"scai-h1\">{$title}</h1>\n</header>";
	}

	private static function rebuild_featured_image( $comp ) {
		$src = esc_url( $comp['src'] );
		$alt = esc_attr( $comp['alt'] );
		$caption = isset( $comp['caption'] ) ? esc_html( $comp['caption'] ) : '';

		$html = "<figure data-component=\"scai-featured-image\" class=\"scai-featured-image\">\n";
		$html .= "  <img src=\"{$src}\" alt=\"{$alt}\" />\n";
		if ( $caption ) {
			$html .= "  <figcaption>{$caption}</figcaption>\n";
		}
		$html .= "</figure>";
		return $html;
	}

	private static function rebuild_overview( $comp ) {
		$paragraphs = isset( $comp['paragraphs'] ) ? $comp['paragraphs'] : array();
		$html = '<section data-component="scai-overview" class="scai-overview">';
		foreach ( $paragraphs as $p ) {
			$html .= '<p class="scai-paragraph">' . esc_html( $p ) . '</p>';
		}
		$html .= '</section>';
		return $html;
	}

	private static function rebuild_section( $comp, $outer ) {
		$heading = esc_html( $comp['heading'] );
		$section_id = ! empty( $comp['section_id'] ) ? $comp['section_id'] : '';
		$paragraphs = isset( $comp['paragraphs'] ) ? $comp['paragraphs'] : array();

		$id_attr = $section_id ? ' id="' . esc_attr( $section_id ) . '"' : '';
		$html = "<section data-component=\"scai-section\"{$id_attr} class=\"scai-section\">\n";
		$html .= "  <h2 class=\"scai-h2\">{$heading}</h2>\n";

		// Preserve image if it exists in original.
		if ( ! empty( $comp['image_src'] ) ) {
			$img_src = esc_url( $comp['image_src'] );
			$img_alt = esc_attr( isset( $comp['image_alt'] ) ? $comp['image_alt'] : '' );
			$img_cap = isset( $comp['image_caption'] ) ? esc_html( $comp['image_caption'] ) : '';
			$html .= "  <figure class=\"scai-h2-image\">\n";
			$html .= "    <img src=\"{$img_src}\" alt=\"{$img_alt}\" />\n";
			if ( $img_cap ) {
				$html .= "    <figcaption>{$img_cap}</figcaption>\n";
			}
			$html .= "  </figure>\n";
		}

		foreach ( $paragraphs as $p ) {
			$html .= '<p class="scai-paragraph">' . esc_html( $p ) . '</p>';
		}

		$html .= '</section>';
		return $html;
	}

	private static function rebuild_faq( $comp, $outer ) {
		// Extract the wrapper class from original outer HTML.
		$wrapper_class = 'scai-faq-studio';
		if ( preg_match( '/class="([^"]*scai-faq-[^"]*)"/', $outer, $m ) ) {
			$wrapper_class = $m[1];
		}
		$wrapper_id = '';
		if ( preg_match( '/id="([^"]*)"/', $outer, $m ) ) {
			$wrapper_id = $m[1];
		}

		$title = esc_html( isset( $comp['title'] ) ? $comp['title'] : 'Frequently Asked Questions' );
		$items = isset( $comp['items'] ) ? $comp['items'] : array();

		$id_attr = $wrapper_id ? ' id="' . esc_attr( $wrapper_id ) . '"' : '';
		$html = "<div class=\"scai-component\"><div class=\"{$wrapper_class}\" data-component=\"scai-faq-section\"{$id_attr}>\n";
		$html .= "<h2 class=\"scai-faq-h2\" data-component=\"scai-faq-h2\">{$title}</h2>\n\n";

		foreach ( $items as $item ) {
			$q = esc_html( $item['q'] );
			$a = esc_html( $item['a'] );
			$html .= "<div class=\"scai-faq-item\">\n";
			$html .= "  <h3 class=\"scai-faq-h3\">{$q}</h3>\n";
			$html .= "  <p class=\"scai-faq-answer\">{$a}</p>\n";
			$html .= "</div>\n\n";
		}

		$html .= "</div></div>";
		return $html;
	}

	private static function rebuild_service_info( $comp, $outer ) {
		// Extract wrapper class and ID from original.
		$wrapper_class = 'scai-svc-studio';
		if ( preg_match( '/class="([^"]*scai-svc-[^"]*)"/', $outer, $m ) ) {
			$wrapper_class = $m[1];
		}
		$wrapper_id = '';
		if ( preg_match( '/id="([^"]*)"/', $outer, $m ) ) {
			$wrapper_id = $m[1];
		}

		$header = esc_html( isset( $comp['header'] ) ? $comp['header'] : '' );
		$rows = isset( $comp['rows'] ) ? $comp['rows'] : array();

		$id_attr = $wrapper_id ? ' id="' . esc_attr( $wrapper_id ) . '"' : '';
		$html = "<div class=\"scai-component\"><div class=\"{$wrapper_class}\" data-component=\"scai-service-info-box\"{$id_attr}>\n";
		$html .= "<div class=\"scai-svc-header\">{$header}</div>\n";

		foreach ( $rows as $row ) {
			$label = esc_html( $row['label'] );
			$value = esc_html( $row['value'] );
			$html .= "<div class=\"scai-svc-row\"><span class=\"scai-svc-label\">{$label}</span><span class=\"scai-svc-value\">{$value}</span></div>\n";
		}

		$html .= "</div></div>";
		return $html;
	}

	private static function rebuild_why_local( $comp, $outer ) {
		// Extract wrapper class and ID from original.
		$wrapper_class = 'scai-local-studio';
		if ( preg_match( '/class="([^"]*scai-local-[^"]*)"/', $outer, $m ) ) {
			$wrapper_class = $m[1];
		}
		$wrapper_id = '';
		if ( preg_match( '/id="([^"]*)"/', $outer, $m ) ) {
			$wrapper_id = $m[1];
		}

		$title = esc_html( isset( $comp['title'] ) ? $comp['title'] : '' );
		$badge = esc_html( isset( $comp['badge'] ) ? $comp['badge'] : 'Local Partner' );
		$image_src = isset( $comp['image_src'] ) ? esc_url( $comp['image_src'] ) : '';
		$items = isset( $comp['items'] ) ? $comp['items'] : array();

		$id_attr = $wrapper_id ? ' id="' . esc_attr( $wrapper_id ) . '"' : '';
		$html = "<div class=\"scai-component\"><div class=\"{$wrapper_class}\" data-component=\"scai-why-local-section\"{$id_attr}>\n";

		if ( $image_src ) {
			$html .= "<div class=\"scai-local-image\">\n<img src=\"{$image_src}\" alt=\"Local Provider\" class=\"scai-local-img\">\n</div>\n";
		}

		$html .= "<div class=\"scai-local-content\">\n";
		$html .= "<span class=\"scai-local-badge\">{$badge}</span>\n";
		$html .= "<h2 class=\"scai-local-title\">{$title}</h2>\n";
		$html .= "<ul class=\"scai-local-list\">\n";
		foreach ( $items as $item ) {
			$html .= "<li>" . esc_html( $item ) . "</li>\n";
		}
		$html .= "</ul>\n</div>\n</div></div>";
		return $html;
	}

	private static function rebuild_closing( $comp ) {
		$heading = esc_html( isset( $comp['heading'] ) ? $comp['heading'] : '' );
		$paragraphs = isset( $comp['paragraphs'] ) ? $comp['paragraphs'] : array();

		$html = "<section data-component=\"scai-closing\" class=\"scai-closing\">\n";
		if ( $heading ) {
			$html .= "  <h2 class=\"scai-h2\">{$heading}</h2>\n";
		}
		foreach ( $paragraphs as $p ) {
			$html .= "  <p class=\"scai-paragraph\">" . esc_html( $p ) . "</p>\n";
		}
		$html .= "</section>";
		return $html;
	}

	/**
	 * For complex components (like product cards), parse original outer HTML
	 * and replace specific values using DOM manipulation.
	 */
	private static function rebuild_from_outer( $comp, $outer ) {
		if ( empty( $outer ) ) {
			return '';
		}

		$doc = new DOMDocument();
		libxml_use_internal_errors( true );
		$doc->loadHTML( '<?xml encoding="UTF-8"><div>' . $outer . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();

		$xpath = new DOMXPath( $doc );

		// Update product card fields.
		if ( isset( $comp['name'] ) ) {
			$nodes = $xpath->query( '//*[contains(@class,"scai-pc-title")]' );
			if ( $nodes->length > 0 ) $nodes->item( 0 )->textContent = $comp['name'];
		}
		if ( isset( $comp['rating'] ) ) {
			$nodes = $xpath->query( '//*[contains(@class,"scai-pc-rating-num")]' );
			if ( $nodes->length > 0 ) $nodes->item( 0 )->textContent = $comp['rating'];
		}
		if ( isset( $comp['price'] ) ) {
			$nodes = $xpath->query( '//*[contains(@class,"scai-pc-price")]' );
			if ( $nodes->length > 0 ) $nodes->item( 0 )->textContent = $comp['price'];
		}
		if ( isset( $comp['description'] ) ) {
			$nodes = $xpath->query( '//*[contains(@class,"scai-pc-desc")]' );
			if ( $nodes->length > 0 ) $nodes->item( 0 )->textContent = $comp['description'];
		}
		if ( isset( $comp['cta_text'] ) ) {
			$nodes = $xpath->query( '//*[contains(@class,"scai-pc-cta")]' );
			if ( $nodes->length > 0 ) $nodes->item( 0 )->textContent = $comp['cta_text'];
		}
		if ( isset( $comp['cta_url'] ) ) {
			$nodes = $xpath->query( '//*[contains(@class,"scai-pc-cta")]' );
			if ( $nodes->length > 0 ) $nodes->item( 0 )->setAttribute( 'href', $comp['cta_url'] );
		}
		if ( isset( $comp['image_src'] ) ) {
			$nodes = $xpath->query( '//img' );
			if ( $nodes->length > 0 ) $nodes->item( 0 )->setAttribute( 'src', $comp['image_src'] );
		}
		if ( isset( $comp['badge'] ) ) {
			$nodes = $xpath->query( '//*[contains(@class,"scai-pc-badge")]' );
			if ( $nodes->length > 0 ) $nodes->item( 0 )->textContent = $comp['badge'];
		}

		// Extract the inner HTML of our wrapper div.
		$wrapper = $doc->getElementsByTagName( 'div' )->item( 0 );
		return self::get_inner_html( $wrapper, $doc );
	}

	/**
	 * Build the Table of Contents HTML from section headings.
	 */
	private static function build_toc_html( $headings, $original_content ) {
		if ( empty( $headings ) ) {
			return '';
		}

		// Try to detect the TOC variation class from original.
		$toc_class = 'scai-toc-clean';
		if ( preg_match( '/class="(scai-toc-[a-z]+)"/', $original_content, $m ) ) {
			$toc_class = $m[1];
		}
		$toc_id = 'scai-q-toc-1';
		if ( preg_match( '/id="(scai-[a-z]+-toc-\d+)"/', $original_content, $m ) ) {
			$toc_id = $m[1];
		}

		$html = "<div class=\"scai-component\"><nav class=\"{$toc_class}\" data-component=\"scai-table-of-contents\" id=\"{$toc_id}\">\n";
		$html .= "<div class=\"scai-toc-title\">Table of Contents</div>\n";
		$html .= "<ul class=\"scai-toc-list\">\n";

		foreach ( $headings as $h ) {
			$id = esc_attr( $h['id'] );
			$title = esc_html( $h['title'] );
			$html .= "<li><a href=\"#{$id}\">{$title}</a></li>\n";
		}

		$html .= "</ul>\n</nav></div>";
		return $html;
	}

	/* ─── Utility Methods ─────────────────────────────────────────── */

	/**
	 * Extract the HTML from the Gutenberg block comment.
	 */
	private static function extract_block_html( $post_content ) {
		// Match content between <!-- wp:scai/article --> and <!-- /wp:scai/article -->
		if ( preg_match( '/<!-- wp:scai\/article[^>]*-->\s*(.*?)\s*<!-- \/wp:scai\/article -->/s', $post_content, $m ) ) {
			return $m[1];
		}
		// If no block comment, try using the raw content.
		if ( strpos( $post_content, 'data-component' ) !== false ) {
			return $post_content;
		}
		return '';
	}

	/**
	 * Extract a meta attribute from the article tag.
	 */
	private static function extract_article_meta( $content, $attr ) {
		if ( preg_match( '/' . preg_quote( $attr, '/' ) . '="([^"]*)"/', $content, $m ) ) {
			return $m[1];
		}
		return '';
	}

	/**
	 * Extract the JSON attributes from the block comment.
	 * e.g. <!-- wp:scai/article {"variation":"clean-studio","colorTheme":"default"} -->
	 * Returns the JSON string or empty.
	 */
	private static function extract_block_attrs( $content ) {
		if ( preg_match( '/<!-- wp:scai\/article\s+(\{[^}]+\})\s*-->/', $content, $m ) ) {
			return $m[1];
		}
		return '';
	}

	/**
	 * Extract the opening wrapper tag from the block content.
	 * Export uses: <div class="wp-block-scai-article scai-wrapper" data-variation="..." ...>
	 * Fallback to <article> for raw HTML.
	 */
	private static function extract_wrapper_tag( $content ) {
		$html = self::extract_block_html( $content );
		// Try Gutenberg wrapper div.
		if ( preg_match( '/<div\s[^>]*wp-block-scai-article[^>]*>/', $html, $m ) ) {
			return $m[0];
		}
		// Fallback: article tag.
		if ( preg_match( '/<article[^>]*>/', $html, $m ) ) {
			return $m[0];
		}
		return '<div class="wp-block-scai-article scai-wrapper">';
	}

	/**
	 * Get outer HTML of a DOMNode.
	 */
	private static function get_outer_html( $node, $doc ) {
		return $doc->saveHTML( $node );
	}

	/**
	 * Get inner HTML of a DOMNode.
	 */
	private static function get_inner_html( $node, $doc ) {
		$html = '';
		foreach ( $node->childNodes as $child ) {
			$html .= $doc->saveHTML( $child );
		}
		return $html;
	}

	/**
	 * Get a human-readable label for a component type.
	 */
	private static function get_component_label( $type ) {
		$labels = array(
			'scai-h1'                => 'Title',
			'scai-featured-image'    => 'Featured Image',
			'scai-overview'          => 'Overview',
			'scai-table-of-contents' => 'Table of Contents',
			'scai-section'           => 'Content Section',
			'scai-faq-section'       => 'FAQ',
			'scai-product-card'      => 'Product Card',
			'scai-service-info-box'  => 'Service Info',
			'scai-why-local-section' => 'Why Choose Local',
			'scai-closing'           => 'Closing',
			'scai-faq-h2'            => 'FAQ Title',
			'scai-cta-box'           => 'Call to Action',
			'scai-feature-section'   => 'Features',
			'scai-ingredients-section'  => 'Ingredients',
			'scai-instructions-section' => 'Instructions',
			'scai-nutrition-section'    => 'Nutrition Facts',
			'scai-tips-section'         => 'Tips',
			'scai-pros-cons-section'    => 'Pros & Cons',
			'scai-rating-section'       => 'Rating',
			'scai-features-section'     => 'Features',
		);

		return isset( $labels[ $type ] ) ? $labels[ $type ] : ucwords( str_replace( array( 'scai-', '-' ), array( '', ' ' ), $type ) );
	}

	/**
	 * Get an SVG icon for the sidebar component buttons.
	 */
	private static function get_component_svg( $icon ) {
		$svgs = array(
			'section'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="20" height="20"><path d="M4 6h16M4 10h16M4 14h10"/></svg>',
			'faq'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="20" height="20"><circle cx="12" cy="12" r="10"/><path d="M9 9a3 3 0 015.12 2.13c0 2-3 2.5-3 4.37M12 17h.01"/></svg>',
			'product'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="20" height="20"><rect x="2" y="3" width="20" height="18" rx="2"/><line x1="2" y1="9" x2="22" y2="9"/><path d="M9 14h6M9 17h4"/></svg>',
			'info'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="20" height="20"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="8" y1="8" x2="16" y2="8"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="8" y1="16" x2="12" y2="16"/></svg>',
			'local'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="20" height="20"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg>',
			'closing'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="20" height="20"><path d="M4 6h16M4 10h16M4 14h16M4 18h8"/></svg>',
		);
		return isset( $svgs[ $icon ] ) ? $svgs[ $icon ] : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="20" height="20"><rect x="3" y="3" width="18" height="18" rx="2"/></svg>';
	}

	/**
	 * Get an SVG icon for a component card header by its data-component type.
	 */
	private static function get_card_icon( $type ) {
		$map = array(
			'scai-h1'                => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><path d="M6 4v16M18 4v16M6 12h12"/></svg>',
			'scai-featured-image'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>',
			'scai-overview'          => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><path d="M4 6h16M4 10h16M4 14h10"/></svg>',
			'scai-table-of-contents' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>',
			'scai-section'           => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><path d="M4 6h16M4 10h16M4 14h16M4 18h8"/></svg>',
			'scai-faq-section'       => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><circle cx="12" cy="12" r="10"/><path d="M9 9a3 3 0 015.12 2.13c0 2-3 2.5-3 4.37M12 17h.01"/></svg>',
			'scai-product-card'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><rect x="2" y="3" width="20" height="18" rx="2"/><line x1="2" y1="9" x2="22" y2="9"/></svg>',
			'scai-service-info-box'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="8" y1="8" x2="16" y2="8"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="8" y1="16" x2="12" y2="16"/></svg>',
			'scai-why-local-section' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg>',
			'scai-closing'           => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><path d="M4 6h16M4 10h16M4 14h16M4 18h8"/></svg>',
		);
		return isset( $map[ $type ] ) ? $map[ $type ] : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><rect x="3" y="3" width="18" height="18" rx="2"/></svg>';
	}
}
